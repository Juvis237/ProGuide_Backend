<?php

namespace App\Http\Livewire\Pages;


use App\Models\Admin;
use App\Models\Page;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class Edit extends Component
{
    public function render()
    {
        return view('livewire.pages.edit');
    }


    public $showModal = false;
    public $isEditMode = false;
    public $title = '';
    public Page $page;
    public $description = '';

    protected function getRules()
    {
        return [
            "title" => 'required',
            'description' => 'nullable',
        ];
    }


    public function load(Page $page)
    {
        $this->page = $page;
        if (isset($page) && $page->exists) {
            $this->isEditMode = true;
            $this->title = $page->title;
            $this->description = $page->content;
        }
        $this->showModal = true;
    }

    protected $listeners = [
        'load'
    ];


    public function save()
    {
        $data = $this->withValidator(function (\Illuminate\Validation\Validator $validator) {
            $validator->after(function (Validator $validator) {
            });
        })->validate();


        $data['content'] = $data['description'];
        $this->page->update($data);

        $this->emit("success", "Page content updated successfully");
        $this->emit("pageUpdated");
        $this->showModal = false;
    }

    public function updatedShowModal($value)
    {
        if (!$value) {
            $this->title = "";
            $this->description = "";
        }
    }
}
