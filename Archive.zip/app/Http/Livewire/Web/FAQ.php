<?php

namespace App\Http\Livewire\Web;
use App\Http\Livewire\DataTable\DataTable;
use App\Models\FAQ as faqs;
use Illuminate\Http\Request;
use Livewire\Component;

class FAQ extends Component
{

    use DataTable;

    public function mount(){
        $this->resetFilters();
        $this->resetSort();
        $this->perPage = 15;
        $this->page = 1;
    }



    protected $listeners = [

    ];
    public function render()
    {
        return view('livewire.web.f-a-q', ['faqs'=>$this->rows] )->layout('layouts.web');
    }

    /**
     * Configure sort when loading the page or switching the tab group
     *
     * @return void
     */
    private function resetSort()
    {
        $this->sortField = 'created_at';
        $this->sortDirection = 'desc';
    }


    protected function getBaseQuery()
    {
        return faqs::query()->select('faqs.*');
    }

    public function resetFilters()
    {
        $this->filters = ["name"=>''];
    }

    public function filterName($query, $value)
    {
        if (strlen($value) === 0) {
            return $query;
        }

        return $query;
    }
}
