<?php

namespace App\Http\Livewire\Web;

use App\Models\Blog;
use Illuminate\Http\Request;
use Livewire\Component;
use Illuminate\Contracts\Validation\Validator;

class Comments extends Component
{
    public $listeners = ['showReply'=>'showReply', 'reply'=>'reply', 'like'=>'like', 'dislike'=>'dislike'];

    public $anonymous = false;
    public $liked = false;
    public $check = '';
    public $disliked = false;
    public $name = '';
    public $email = '';
    public $content = '';
    public $post = null;

    public $showReplyVar = false;
    public $reply_comment = null;

    public $comments = null;
    public function mount(Blog $post){
        $this->post = $post;
        $this->comments = \App\Models\Comment::where('post_id', $this->post->id)->get();
    }

    public function like($id){
        $comment = \App\Models\Comment::find($id);
        $comment->likes++;
        $comment->save();
        $this->liked = true;
        $this->comments = \App\Models\Comment::where('post_id', $this->post->id)->get();
    }

    public function dislike($id){
        $comment = \App\Models\Comment::find($id);
        $comment->dislikes++;
        $comment->save();
        $this->disliked = true;
        $this->comments = \App\Models\Comment::where('post_id', $this->post->id)->get();
    }

    public function reply($id){
        $data = $this->withValidator(function (\Illuminate\Validation\Validator $validator) {
            $validator->after(function (Validator $validator) {

            });
        })->validate();
        $data['post_id'] = $this->post->id;
        $data['parent_id'] = $id;
        $comment = new \App\Models\Comment();
        $comment->create($data);
        $this->emit('success', 'comment created successively');
        unset($this->name, $this->email, $this->content, $this->reply_comment,);
        $this->showReplyVar=false;
        $this->comments = \App\Models\Comment::where('post_id', $this->post->id)->get();

    }


    protected $rules = [
        "name" => 'required',
        "email" => 'email|nullable',
        "content" => 'required',

    ];

    public function showReply($id){

        if($this->showReplyVar){
            $this->showReplyVar = false;
            return;
        }
        $this->showReplyVar = true;
        $this->reply_comment = $id;
    }

    public function sendComment(){
        $data = $this->withValidator(function (\Illuminate\Validation\Validator $validator) {
            $validator->after(function (Validator $validator) {

            });
        })->validate();
        $data['post_id'] = $this->post->id;
        $comment = new \App\Models\Comment();
        $comment->create($data);
        $this->emit('success', 'comment created successively');
        unset($this->name, $this->email, $this->content);
        $this->comments = \App\Models\Comment::where('post_id', $this->post->id)->get();
        }

    public function render()
    {
        return view('livewire.web.comments');
    }
}
