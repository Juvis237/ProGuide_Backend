<?php

namespace App\Http\Livewire\Web;

use Livewire\Component;

class Home extends Component
{
    public $for_worker = '1' ;
    public function toWorker($val){
      
       if($this->for_worker == $val){
        return;
       }else {
        $this->for_worker = $val;
       }
    }
    public function render()
    {
        return view('livewire.web.home')->layout('layouts.web');
    }
}
