<?php

namespace App\Http\Livewire\Web\About;

use Livewire\Component;

class Team extends Component
{
    public function render()
    {
        return view('livewire.web.about.team')->layout('layouts.web');
    }
}
