<?php

namespace App\Http\Livewire\Web\About;

use Livewire\Component;

class Index extends Component
{
    public function render()
    {
        return view('livewire.web.about.index')->layout('layouts.web');
    }
}
