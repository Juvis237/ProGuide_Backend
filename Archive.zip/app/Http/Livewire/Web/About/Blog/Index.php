<?php

namespace App\Http\Livewire\Web\About\Blog;

use App\Helpers\Constants;
use App\Http\Livewire\DataTable\DataTable;
use App\Models\Blog;
use App\Models\Category;
use Livewire\Component;

class Index extends Component
{

    use DataTable;

    /**
     * Configure sort when loading the page or switching the tab group
     *
     * @return void
     */
    private function resetSort()
    {
        $this->sortField = 'created_at';
        $this->sortDirection = 'desc';
    }


    public $categories = [];

    public function setFilter($index, $value){
        $this->filters[$index] = $value;
    }

    public function mount(\Illuminate\Http\Request $request)
    {
        $this->resetFilters();
        $this->resetSort();
        $this->perPage = 10;
        $this->page = 1;
    }

    protected function getBaseQuery()
    {
        return Blog::query()->select('blogs.*')->where('status', 'published');
    }

    public function resetFilters()
    {
        $this->filters = [
            "name"=>'',
            "category"=>[],
        ];
    }

    public function filterName($query, $value)
    {
        if (strlen($value) === 0) {
            return $query;
        }

        return $query->where('title','like',"%{$value}%")->orWhere('description','like',"%{$value}%");
    }



    public function filterCategory($query, $value)
    {
        if (count($value) === 0) {
            return $query;
        }

        return $query->whereIn('category_id',$value);
    }



    public function render()
    {
        return view('livewire.web.about.blog.index', ['blogs' => $this->rows])->layout('layouts.web');
    }


}
