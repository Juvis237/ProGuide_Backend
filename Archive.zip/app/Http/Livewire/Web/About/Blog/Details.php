<?php

namespace App\Http\Livewire\Web\About\Blog;

use Livewire\Component;
use App\Models\Blog;
class Details extends Component
{
    public $listeners = ['commentCreated'=> '$refresh'];
    public Blog $blog;
    public function mount(?Blog $blog){
        $this->blog = $blog;
    }
    public function render()
    {
        return view('livewire.web.about.blog.details')->layout('layouts.web');
    }
}
