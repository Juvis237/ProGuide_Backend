<?php

namespace App\Http\Livewire\Web;

use Livewire\Component;

class Error extends Component
{
    public function render()
    {
        return view('livewire.web.error')->layout('layouts.web');
    }
}
