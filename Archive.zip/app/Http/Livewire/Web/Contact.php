<?php

namespace App\Http\Livewire\Web;

use App\Models\User;
use App\Notifications\NewContactMessage;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Facades\Notification;
use Livewire\Component;

class Contact extends Component
{
    public $name = '';
    public $email = '';

    public $subject = '';

    public $content = '';

    protected $rules = [
        "name" => 'required',
        "subject" => 'required',
        "content" => 'required',
        "email" => 'required|email',
    ];


    public function send(){
        $data = $this->withValidator(function (\Illuminate\Validation\Validator $validator) {
            $validator->after(function (Validator $validator) {

            });
        })->validate();
        $details['greeting'] = 'Hi ';
        $details['subject'] = 'New Contact Message';
        $details['body'] = "<p>Name : {$this->name}</p><p>Email : {$this->email}</p> <p>Subject : {$this->subject}<p>Content : {$this->content}</p> ";
        $admins = User::whereAdmin('1')->get();
        try{
            Notification::send($admins, new NewContactMessage($details));
            $this->emit("success", "Message sent successfully");
        }catch(\Exception $e){
            $this->emit("error", "An error occured please try again");
        }
        
        return redirect()->back();
    }
    public function render()
    {
        return view('livewire.web.contact')->layout('layouts.web');
    }
}
