<?php

namespace App\Http\Livewire\Requests\Findpro;

use App\Models\Cities;
use App\Models\Regions;
use App\Models\Skill;
use Illuminate\Http\Request;
use Livewire\Component;

class Search extends Component
{
    public $region_id;
    public $city_id;
    public $categories = [];
    public $sub_categories = [];
    public $regions = [];
    public $cities = [];

    public $advance_search = true;

    public $filters = [
        "name"=>'',
        "category"=>'',
        "sub_category"=>'',
        "region"=>'',
        "city"=>'',
    ];

    protected $listeners = [
        'load' => 'load',

    ];

    public function mount(Request $request, $showModal){
        $this->categories = Skill::whereNull('skill_id')->get();
        $this->regions = Regions::all();
        $this->advance_search = true;
        if(isset($showModal)){
            $this->showModal = $showModal;
        }
    }

    public function load(){
        $this->showModal = true;
    }

    public function setAdvance(){
        $this->advance_search = $this->advance_search?false:true;
    }

    public function set_sub(){
        $this->sub_categories = Skill::where('skill_id', Skill::where('name', $this->filters['category'])->first()->id)->get();
    }

    public function set_cities(){
        $this->cities = Cities::where('region_id', Regions::where('name', $this->filters['region'])->first()->id)->get();;
    }

    public function search(){
        $this->showModal = false;
       $this->emit("search", $this->filters);
    }


    public function render()
    {
        return view('livewire.requests.findpro.search');
    }
}
