<?php

namespace App\Http\Livewire\Requests\Findpro;

use App\Models\User;
use App\Notifications\SendMail as NotificationsSendMail;
use Livewire\Component;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Notification;

class SendMail extends Component
{
    public $showModal = false;
    public User $user;
    public $subject = "";

    public $content = "";
    public $greeting = "";



    protected $listeners = [
        'load'=>'load'
    ];


    public function load(User $user){
        $this->user = $user;
        $this->showModal = true;
    }


    protected $rules = [
        "subject" => 'required',
        "content" => 'required',
        "greeting" => 'required',


    ];

    public function send(){
        $data = $this->withValidator(function (\Illuminate\Validation\Validator $validator) {
            $validator->after(function (Validator $validator) {

            });

        })->validate();

        $details['greeting'] = $this->greeting;
        $details['subject'] = $this->subject;
        $details['body'] = $this->content;
        try{
            Notification::send($this->user, new NotificationsSendMail($details));
            $this->emit("success", "Message sent successfully");
        }catch(\Exception $e){
            $this->emit("error", "An error occured please try again");
        }

        $this->showModal = false;


    }
    public function render()
    {
        return view('livewire.requests.findpro.send-mail');
    }
}
