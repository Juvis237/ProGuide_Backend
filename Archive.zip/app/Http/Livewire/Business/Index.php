<?php

namespace App\Http\Livewire\Business;

use App\Http\Livewire\DataTable\DataTable;
use App\Models\Cities;
use App\Models\Regions;
use App\Models\Skill;
use App\Models\User;
use Illuminate\Http\Request;
use Livewire\Component;

class Index extends Component
{

    use DataTable;

    protected $listeners = [
        'userCreated' => '$refresh',
        'userDeleted' => '$refresh',
    ];

    public $categories = [];
    public $sub_categories = [];
    public $regions = [];
    public $cities = [];

    /**
     * Configure sort when loading the page or switching the tab group
     *
     * @return void
     */
    private function resetSort()
    {
        $this->sortField = 'created_at';
        $this->sortDirection = 'desc';
    }


    public function mount(Request $request)
    {
        $this->resetFilters();
        $this->resetSort();
        $this->perPage = 15;
        $this->page = 1;
        $this->regions = Regions::all();
        $this->categories = Skill::whereNull('skill_id')->get();
    }

    protected function getBaseQuery()
    {
        return User::query()->select('users.*')->where('admin', 0)->whereRole('worker');
    }

    public function render()
    {
        return view('livewire.business.index', ['users' => $this->rows]);
    }

    public function resetFilters()
    {
        $this->filters = [
            "name" => '',
            "category" => '',
            "sub_category" => '',
            "region" => '',
            "city" => ''
        ];
    }

    public function filterName($query, $value)
    {
        if (strlen($value) === 0) {
            return $query;
        }

        return $query->where(function ($q) use ($value){
            $q->orWhere('first_name','like',"%$value%")->orWhere('last_name','like',"%$value%")->orWhere('bio','like',"%$value%");
        });
    }

    public function filterRegion($query, $value)
    {
        if (strlen($value) === 0) {
            return $query;
        }

        return $query->where('region_id',$value);
    }

    public function filterCity($query, $value)
    {
        if (strlen($value) === 0) {
            return $query;
        }

        return $query->where('city_id', $value);
    }

    public function filterCategory($query, $value)
    {
        $main = $this->filters['category'];
        $sub = $this->filters['sub_category'];

        if (strlen($value) === 0) {
            return $query;
        }

        return $query->whereHas('services', function ($q) use ($main, $sub){
            return $q->whereHas('userServiceSkill', function ($qq) use ($main, $sub){
                return $qq->whereIn('skill_id', [$main, $sub]);
            });
        });

    }

    public function filterSubCategory($query, $value)
    {
        $main = $this->filters['category'];
        $sub = $this->filters['sub_category'];

        if (strlen($value) === 0) {
            return $query;
        }

        return $query->whereHas('services', function ($q) use ($main, $sub){
            return $q->whereHas('userServiceSkill', function ($qq) use ($main, $sub){
                return $qq->whereIn('skill_id', [$main, $sub]);
            });
        });

    }

    public function updated($key)
    {
        if($key == "filters.region"){
            $query = $this->getBaseQuery();
            $this->applyFilters($query);
            $this->cities = [];
            $this->filters['city'] = "";
        }

        if($key == "filters.category"){
            $query = $this->getBaseQuery();
            $this->applyFilters($query);
        }
    }

    public function set_sub(){
        $this->sub_categories = Skill::where('skill_id',$this->filters['category'])->get();
    }

    public function set_cities(){
        $this->cities = Cities::where('region_id', $this->filters['region'])->get();;
    }
}



