<?php

namespace Database\Seeders;

use App\Models\Page;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $faker = \Faker\Factory::create();
        Page::create(['title' => "Privacy Ploicy", 'content' => $faker->realText]);
        Page::create(['title' => "Terms And Condition", 'content' => $faker->realText]);
        Page::create(['title' => "We Help You Find and Hire the Right Professionals", 'content' => $faker->realText]);
        Page::create(['title' => "Our Search Feature to Filter Professionals", 'content' => $faker->realText]);
        Page::create(['title' => "Our Search Feature to Filter Professionals", 'content' => $faker->realText]);
        Page::create(['title' => "How It Works", 'content' => $faker->realText]);
        Page::create(['title' => "About Footer", 'content' => $faker->realText]);
        Page::create(['title' => "We Help You Find and Hire the Right Professionals", 'content' => $faker->realText]);
        Page::create(['title' => "How to Get Started", 'content' => $faker->realText]);
        Page::create(['title' => "The Best Hiring Platform for Professionals", 'content' => $faker->realText]);
        Page::create(['title' => "Clients Find You on Pro4Home", 'content' => $faker->realText]);
        Page::create(['title' => "Create and Customize your Business Profile", 'content' => $faker->realText]);
        Page::create(['title' => "Promote Your Business and Services and Make more Money", 'content' => $faker->realText]);
        Page::create(['title' => "Our Address", 'content' => "Carrefour Yoro Joss, Bonamoussadi Douala, Cameroon"]);
        Page::create(['title' => "Call Us", 'content' => "+237 987 889 874<br>+237 658 985 899"]);
        Page::create(['title' => "Write Us", 'content' => "info@pro4home.com<br>support@pro4home.com"]);
        Page::create(['title' => "App Store", 'content' => "https://www.google.com/"]);
        Page::create(['title' => "Play Store", 'content' => "https://www.google.com/"]);
        Page::create(['title' => "Facebook", 'content' => "https://www.google.com/"]);
        Page::create(['title' => "Twitter", 'content' => "https://www.google.com/"]);
        Page::create(['title' => "Youtube", 'content' => "https://www.google.com/"]);

        User::create([
            'name' => "admin",
            'phone' => "1234567",
            'email' => 'admin@gmail.com',
            'admin' => 1,
            'password' => Hash::make("password"),
        ]);

        User::create([
            'name' => "F Taptue",
            'phone' => "6777777777",
            'email' => 'ftaptue@pro4h.com',
            'admin' => 1,
            'password' => Hash::make("password"),
        ]);

        $this->call(PermissionsSeeder::class);
        $this->call(JobSeeder::class);
        $this->call(RoleSeeder::class);
        $this->call(RolePermissionSeeder::class);
        $this->call(LocationSeerder::class);
        $this->call(UserPermissionSeeder::class);
        $this->call(UserRoleSeeder::class);
    }
}
