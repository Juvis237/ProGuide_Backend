<img src="{{asset('be_assets/images/Rectangle 2.png')}}" class=" h-12 md:h-14 lg:h-16">
