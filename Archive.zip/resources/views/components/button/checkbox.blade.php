<input type="checkbox"
    {{ $attributes->merge([
        'class' =>
            'border-[0.125rem] border-white bg-transparent rounded-[3px] h-[13px] w-[13px]',
    ]) }}/>
