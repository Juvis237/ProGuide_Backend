<input type="radio"
    {{ $attributes->merge([
        'class' =>
            'border-[0.125rem] border-white bg-transparent',
    ]) }}/>
