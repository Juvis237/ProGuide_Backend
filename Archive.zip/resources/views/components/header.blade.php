<div class=" bg-light py-16 flex justify-center align-center">
    <span>
        <p class=" font-bold text-4xl ">{{$title}}</p>
        <center><div style="height: 2px; width: 100px" class="bg-orange mt-4"></div></center>
    </span>
</div >