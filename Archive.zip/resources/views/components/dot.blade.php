<span
    {{ $attributes->merge([
            'class' => 'h-1.5 w-1.5 rounded-full inline-flex',
    ]) }}
>
</span>
