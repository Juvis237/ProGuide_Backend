<button
    {{ $attributes->merge([
            'type' => 'button',
    ]) }}
>
    {{ $slot }}
</button>
