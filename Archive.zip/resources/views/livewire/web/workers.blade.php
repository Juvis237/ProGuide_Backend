<div class="flex  justify-center ">
    <div class="grid grid-cols-2  w-full">
        <div class="col-span-2 md:col-span-1 bg-orange">
            <div class="flex px-8 py-8 lg:px-24 h-[80vh] md:h-full  items-center">
                <div data-te-animation-init data-te-animation-start="onLoad" data-te-animation-reset="true"
                    data-te-animation="slide-right_1s_ease-in-out" viewBox="0 0 24 24" class="">
                    <h1 class="text-4xl mb-5 font-bold text-white text-center md:text-left">
                        {!! \App\Models\Page::find(8)->title !!}
                    </h1>
                    <p class="text-white text-center leading-6 mt-4 md:text-left">
                        {!! \App\Models\Page::find(8)->content !!}
                    </p>
                    <div class="flex flex-row justify-center md:justify-start mt-6 space-x-4">
                        <a href="{!! \App\Models\Page::find(17)->content !!}">
                            <img src="{{ asset('images/img_homepage/appstore12.png') }}" alt="">
                        </a>
                        <a href="{!! \App\Models\Page::find(18)->content !!}">
                            <img src="{{ asset('images/img_homepage/playstore.png') }}" alt="">
                        </a>
                    </div>
                </div>
            </div>

        </div>
        <div class="md:col-span-1 hidden md:flex">
            <img src="{{ asset('images/img-for-workers-hero.png') }}" class="h-[827px] w-full" alt="">
        </div>

    </div>

</div>

<section class="mt-24">
    <div class="container mx-8 lg:mx-24">
        <div class="mb-6 mx-auto">
            <h1 class="text-5xl mb-8  font-bold text-left">
                {!! \App\Models\Page::find(9)->title !!}
            </h1>
            <p class="text-left text-gray-500 md:w-1/3">
                {!! \App\Models\Page::find(9)->content !!}
            </p>
        </div>
        <div class="grid grid-cols-3 my-16 gap-4 ">
            <div class="  col-span-3 md:col-span-2 lg:col-span-1 p-6 my-4  bg-white rounded-lg shadow-xl shadow-light ">
                <img src="{{ asset('images/img_workers/icons8_signing_a_document 1.svg') }}" alt="">
                <a href="#">
                    <h3 class="mb-4 mt-12 text-3xl font-bold tracking-tight text-secondary-2 ">Set up your
                        account</h3>
                </a>
                <p class="mb-3 font-normal text-gray-500 ">Lorem ipsum dolor sit amet consectetur.
                    A et
                    ut viverra eget erat arcu nullam. Arcu dignissim
                    nisl turpis laoreet neque quis. </p>
            </div>
            <div class=" col-span-3 md:col-span-2 lg:col-span-1 p-6 my-4 bg-white rounded-lg ">
                <img src="{{ asset('images/img_workers/icons8_verified_account 1.svg') }}" alt="">
                <a href="#">
                    <h3 class="mb-4 mt-12 text-3xl font-bold tracking-tight text-gray-800 ">Get
                        Verified</h3>
                </a>
                <p class="mb-3 font-normal text-gray-500 ">Lorem ipsum dolor sit amet consectetur.
                    A et
                    ut viverra eget erat arcu nullam. Arcu dignissim
                    nisl turpis laoreet neque quis. </p>
            </div>
            <div class="col-span-3 md:col-span-2 lg:col-span-1 p-6 my-4 bg-white rounded-lg ">
                <img src="{{ asset('images/img_workers/icons8_commercial 1.svg') }}" alt="">
                <a href="#">
                    <h3 class="mb-4 mt-12 text-3xl font-bold tracking-tight text-gray-800 ">Advertise your
                        Service</h3>
                </a>
                <p class="mb-3 font-normal text-gray-500 ">Lorem ipsum dolor sit amet consectetur.
                    A et
                    ut viverra eget erat arcu nullam. Arcu dignissim
                    nisl turpis laoreet neque quis. </p>
            </div>
        </div>
    </div>
</section>

<div class="bg-light-blue w-full py-16 px-8">
    <div class="flex flex-col justify-center">
        <p class="text-4xl font-bold text-center">Join over 20+ companies <br> working with us</p>
        <div class="mt-8 flex overflow-x-auto  justify-center w-full">
            @for ($i = 0; $i < 5; $i++)
                <x-logo.white />
            @endfor
        </div>
    </div>
</div>

<section class="mt-24">
    <div class="container flex flex-col-reverse px-4 items-center mx-auto mt-10 space-y-12 md:space-y-0 md:flex-row">
        <div class=" hidden lg:flex flex-col space-y-12 md:w-1/2">
            <img src="{{ asset('images/img_workers/Group 1831.png') }}" alt="">
        </div>
        <div class="flex flex-col space-y-8 md:ml-8 md:w-1/2">
            <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                <div class="px-8 md:mx-6">
                    <h1 class=" mb-4 text-4xl font-bold md:block">
                        Why Work With Us?
                    </h1>
                    <p class="text-gray-600">
                        Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat
                        arcu nullam. Arcu dignissim nisl turpis laoreet neque quis.
                    </p>
                    <div class="my-8 ">
                        <div
                            class="flex flex-col  my-4 px-6 py-6  items-center bg-white rounded-2xl shadow-2xl shadow-light-blue md:flex-row ">
                            <img class="w-auto shadow-lg p-2 rounded shadow-light-blue"
                                src="/images/img_workers/icons8_good_quality 1.svg" alt="">
                            <div class="flex flex-col justify-between  ml-6 leading-normal">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 ">
                                    Quality Service</h5>
                                <p class="mb-3 text-sm text-gray-700 ">Lorem ipsum dolor
                                    sit amet consectetur. A
                                    et ut viverra eget erat arcu nullam. Arcu
                                    dignissim nisl turpis laoreet neque quis. </p>
                            </div>
                            </a>
                        </div>
                        <div
                            class="flex flex-col  my-4 px-6 py-6 items-center bg-white rounded-2xl shadow-2xl shadow-light-blue md:flex-row ">
                            <img class="w-auto shadow-lg p-2 rounded shadow-light-blue"
                                src="/images/img_workers/icons8_sell 1.svg" alt="">
                            <div class="flex flex-col justify-between ml-6 leading-normal">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 ">
                                    Sell your business</h5>
                                <p class="mb-3 text-sm text-gray-700 ">Lorem ipsum dolor
                                    sit amet consectetur. A
                                    et ut viverra eget erat arcu nullam. Arcu
                                    dignissim nisl turpis laoreet neque quis. </p>
                            </div>
                            </a>
                        </div>
                        <div
                            class="flex flex-col  my-4 px-6 py-6  items-center bg-white rounded-2xl shadow-2xl shadow-light-blue md:flex-row ">
                            <img class="w-auto shadow-lg p-2 rounded shadow-light-blue"
                                src="/images/img_workers/icons8_good_quality 1.svg" alt="">
                            <div class="flex flex-col justify-between ml-6 leading-normal">
                                <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 ">
                                    Endless profits</h5>
                                <p class="mb-3 text-sm text-gray-700 ">Lorem ipsum dolor
                                    sit amet consectetur. A
                                    et ut viverra eget erat arcu nullam. Arcu
                                    dignissim nisl turpis laoreet neque quis. </p>
                            </div>
                            </a>
                        </div>
                        <button
                            class="text-white bg-secondary-2 my-4 px-6 py-6 w-full rounded-lg block text-sm font-bold ">Get
                            Started</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
