<div>

    <div id="hero" class="bg-secondary-50 flex justify-center pb-16 mb-16">
        <div
            class="container max-w-screen-xl mx-8 lg:mx-auto flex md:px-4 flex-col  md:flex-row items-center space-y-0 md:space-y-0">
            <div data-te-animation-init data-te-animation-start="onLoad" data-te-animation-reset="true"
                data-te-animation="slide-right_1s_ease-in-out" viewBox="0 0 24 24"
                class="flex flex-col my-32 items-center md:pr-12 md:w-1/2 md:items-start">
                <h1 class="text-4xl mb-5 font-bold text-white text-center md:text-left">
                    {!! \App\Models\Page::find(3)->title !!}
                </h1>
                <p class="text-white text-center leading-6 mt-4 md:text-left">
                    {!! \App\Models\Page::find(3)->content !!}
                </p>
                <div class="flex flex-row justify-start mt-6 space-x-4">
                    <a href="{!! \App\Models\Page::find(17)->content !!}">
                        <img src="{{ asset('images/img_homepage/appstore12.png') }}" alt="">
                    </a>
                    <a href="{!! \App\Models\Page::find(18)->content !!}">
                        <img src="{{ asset('images/img_homepage/playstore.png') }}" alt="">
                    </a>
                </div>
            </div>
            <div id="hero_img" class="hidden md:block lg:flex items-center h-full  md:w-1/2 py-16">
                <img src="{{ asset('images/img_homepage/home_hero.png') }}" class="" alt="Hero Image">
            </div>
        </div>
    </div>

    <section id="features">
        <div
            class="container flex flex-col-reverse px-8 items-center mx-auto mt-10 space-y-12 md:space-y-0 md:flex-row">
            <div class="flex flex-col space-y-12 md:w-1/2">
                <img src="{{ asset('images/img_homepage/home_pic_right.svg') }}" alt="">
            </div>
            <div class="flex flex-col space-y-8 md:w-1/2">
                <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                    <div class="mx-auto md:mx-6">
                        <h3 class="mb-4 text-lg text-orange font-extrabold md:block">
                            Feature
                        </h3>
                        <h1 class=" mb-4 text-4xl font-extrabold md:block">
                            {!! \App\Models\Page::find(4)->title !!}

                        </h1>
                        <p class="text-gray-600">
                            {!! \App\Models\Page::find(4)->content !!}

                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container flex flex-col px-4 items-center mx-auto md:-mt-16 space-y-12 md:space-y-0 md:flex-row">
            <div class="flex flex-col space-y-8 md:w-1/2">
                <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                    <div class="mx-auto md:mx-6">
                        <h3 class="mb-4 text-lg text-orange font-extrabold md:block">
                            Feature
                        </h3>
                        <h1 class=" mb-4 text-4xl font-extrabold md:block">
                            {!! \App\Models\Page::find(5)->title !!}
                        </h1>
                        <p class="text-gray-600">
                            {!! \App\Models\Page::find(5)->content !!}
                        </p>
                        <a href="{{ route('features') }}"
                            class="text-white bg-secondary-2 py-5 px-4 my-8 rounded-lg font-extrabold">Discover More
                            Features</a>
                    </div>
                </div>
            </div>
            <div class="flex flex-col space-y-12 md:w-1/2">
                <img src="{{ asset('images/img_homepage/home_pic_left.svg') }}" alt="">
            </div>
        </div>
    </section>

    <section class="mt-24 flex justify-center">
        <div class="container mx-auto">
            <div class="md:px-60">
                <h1 class="text-4xl mb-5 font-extrabold text-center">{!! \App\Models\Page::find(6)->title !!}</h1>
                <div class="flex justify-center">
                    <hr class="border-2 border-orange w-20">
                </div>
                <p class="text-center leading-6 mt-4 ">
                    {!! \App\Models\Page::find(6)->content !!}
                </p>
            </div>
            <div class="flex justify-center mt-8">
                <div class="flex flex-wrap text-sm font-medium text-center text-gray-500 border-b border-gray-200  ">

                    <button wire:click="toWorker('1')"
                        class=" p-4 {{ $for_worker == '1' ? 'bg-secondary text-white font-bold' : 'hover:text-gray-600 hover:bg-gray-50' }} rounded-t-lg">For
                        Workers</button>

                    <button wire:click="toWorker('0')"
                        class=" p-4 rounded-t-lg {{ $for_worker == '0' ? 'bg-secondary text-white font-bold' : 'hover:text-gray-600 hover:bg-gray-50' }}  ">For
                        Clients</button>

                </div>
            </div>
            <div class="flex justify-center {{ $for_worker == '0' ? 'hidden' : '' }} ">
                <div class="flex py-8 px-8 lg:px-16 justify-center border-0 rounded-2xl"
                    style="background-image: url('/images/Rectangle 835.png'); background-repeat : no-repeat; background-size: cover ">
                    <div class="grid grid-cols-6 gap-6">
                        <div class="lg:col-span-1"></div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icons8_software_installer_2 1.png') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 1</p>
                                    <p class="text-xl font-bold mb-4">Install Pro4Home</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icons8_checked_user_female 1.png') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 2</p>
                                    <p class="text-xl font-bold mb-4">Create Your Account</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="lg:col-span-1"></div>
                        <div class="lg:col-span-1"></div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icon-setup-profile.svg') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 3</p>
                                    <p class="text-xl font-bold mb-4">Set Up Your Profile</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icon-setup-profile.svg') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 4</p>
                                    <p class="text-xl font-bold mb-4">Advertise Your Services</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="lg:col-span-1"></div>
                        <div class="lg:col-span-1"></div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icon-get-hired.svg') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 5</p>
                                    <p class="text-xl font-bold mb-4">Get Hired, Get Paid</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="lg:col-span-1"></div>

                    </div>

                </div>
            </div>
            <div class="flex justify-center {{ $for_worker == '1' ? 'hidden' : '' }} ">
                <div class="flex py-8 px-16 justify-center border-0 rounded-2xl"
                    style="background-image: url('/images/Rectangle 835.png'); background-repeat : no-repeat; background-size: cover ">
                    <div class="grid grid-cols-6 gap-6">
                        <div class="lg:col-span-1"></div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icons8_software_installer_2 1.png') }}"
                                        alt="">
                                    <p class="text-base font-bold my-4">Step 1</p>
                                    <p class="text-xl font-bold mb-4">Install Pro4Home</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icons8_checked_user_female 1.png') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 2</p>
                                    <p class="text-xl font-bold mb-4">Create Your Account</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="lg:col-span-1"></div>
                        <div class="lg:col-span-1"></div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icon-search-proffesssional.svg') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 3</p>
                                    <p class="text-xl font-bold mb-4">Search Professionals</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="col-span-6 lg:col-span-2">
                            <div class="bg-white rounded-xl py-8 px-6 shadow-sm">
                                <span>
                                    <img src="{{ asset('images/icon-hire.svg') }}" alt="">
                                    <p class="text-base font-bold my-4">Step 4</p>
                                    <p class="text-xl font-bold mb-4">Choose and Hire !</p>
                                    <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam.
                                        Arcu dignissim nisl turpis laoreet neque quis.</p>
                                </span>
                            </div>
                        </div>
                        <div class="lg:col-span-1"></div>

                    </div>

                </div>
            </div>

        </div>
</div>
</section>

<div class="flex  justify-center mt-16">
    <div class="grid grid-cols-2 gap-2 w-full">
        <div class="md:col-span-1 hidden md:flex">
            <img src="{{ asset('images/img-home-testimonial.png') }}" class="h-full w-full" alt="">
        </div>
        <div class="col-span-2 md:col-span-1 bg-secondary-50">
            <div class="p-8 lg:p-16 text-white">
                <span>
                    <p class="text-4xl font-bold mb-4 ">What Our Customers Are Saying</p>
                    <div class="mb-8 h-1 bg-orange w-24"></div>
                    <p class="text-italic">Pulvinar faucibus augue nibh in purus tempus et volutpat blandit. Enim diam
                        risus praesent placerat et urna volutpat. Tortor tempor mus ut bibendum neque ultricies a netus
                        tellus. Dignissim porttitor orci ultrices at amet. In sed dolor eget in amet imperdiet duis nunc
                        neque. Pharetra mi amet nisl feugiat. Cursus integer donec lorem malesuada sollicitudin amet.
                        Ipsum suspendisse aliquam eu feugiat nec. Viverra nunc amet euismod vel at sit. Metus est
                        viverra est ultricies integer ornare sed. Proin quam in adipiscing feugiat turpis consequat sed.
                        Dignissim fames volutpat neque gravida tincidunt euismod ac nam.</p>
                    <div class="mt-24">
                        <div class="py-2 px-4 border-l border-orange">
                            <span>
                                <p class="text-base font-bold">
                                    Amanda Breitenberg
                                </p>
                                <p class="text-sm text-orange font-bold">
                                    Hermann - Ratke
                                </p>
                            </span>
                        </div>
                    </div>
                </span>
            </div>
        </div>

    </div>

</div>

<section class="my-24">


    <div class="container px-6  md:mx-auto">
        <div class="shadow-2xl bg-gray-50 rounded-2xl mt-10 p-4 py-16">
            <h1 class="text-4xl md:text-5xl mb-5 text-gray-600 font-bold text-center">
                Get <span class="text-secondary">Pro</span><span class="text-orange">4</span><span
                    class="text-secondary">Home</span> App Now
            </h1>
            <p class="text-center leading-6 mt-4 md:px-32">
                And start Finding the right professionals or advertise your services
            </p>
            <div class="flex flex-row justify-center mt-6 space-x-4">
                <a href="{!! \App\Models\Page::find(17)->content !!}">
                    <img src="{{ asset('images/img_homepage/appstore12.png') }}" alt="">
                </a>
                <a href="{!! \App\Models\Page::find(18)->content !!}">
                    <img src="{{ asset('images/img_homepage/playstore.png') }}" alt="">
                </a>
            </div>
        </div>
    </div>
</section>
</div>
