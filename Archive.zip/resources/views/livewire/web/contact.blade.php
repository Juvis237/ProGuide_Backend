<div>
    @include(
        'components.header',
        with([
            'title' => 'Contact Us',
        ]))

    <x-container class="py-16">
        <div class="grid grid-cols-3 gap-4">
            <div class="col-span-3 lg:col-span-1">
                <div class="rounded-2xl border p-4">
                    <div class=" flex justify-center">
                        <div class="rounded-full flex items-center justify-center p-4 bg-secondary ">
                            <img src="{{ asset('images/icon-location.svg') }}" class="text-white" alt="">
                        </div>
                    </div>
                    <div class=" flex justify-center mt-6">
                        <span class="text-center">
                            <p class="text-2xl font-black mb-4">Our Address</p>
                            <p>
                                {!! \App\Models\Page::find(14)->content !!}
                            </p>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col-span-3 lg:col-span-1">
                <div class="rounded-2xl border border-orange p-4 h-full">
                    <div class=" flex justify-center">
                        <div class="rounded-full flex items-center justify-center p-4 bg-secondary ">
                            <img src="{{ asset('images/icon-phone.png') }}" class="text-white" alt="">
                        </div>
                    </div>
                    <div class=" flex justify-center mt-6">
                        <span class="text-center">
                            <p class="text-2xl font-black mb-4">Call Us</p>
                            {!! \App\Models\Page::find(15)->content !!}
                        </span>
                    </div>
                </div>
            </div>

            <div class="col-span-3 lg:col-span-1">
                <div class="rounded-2xl border p-4">
                    <div class=" flex justify-center">
                        <div class="rounded-full flex items-center justify-center p-4 bg-secondary ">
                            <img src="{{ asset('images/icon-send-email.svg') }}" class="text-white" alt="">
                        </div>
                    </div>
                    <div class=" flex justify-center mt-6">
                        <span class="text-center">
                            <p class="text-2xl font-black mb-4">Write Us</p>
                            {!! \App\Models\Page::find(16)->content !!}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </x-container>
    <div class="bg-secondary-50 py-16 ">
        <div class="flex items-center text-center justify-center">
            <p class="text-3xl text-white  font-bold mb-10">Any question? Send us message</p>
        </div>
        <div class="grid grid-cols-5 lg:grid-cols-4 ">
            <div class="col-span-1 lg:col-span-1"></div>
            <div class="col-span-3 lg:col-span-2">
                <div class="grid grid-cols-2 gap-4 text-white">
                    <div class="col-span-2 lg:col-span-1">
                        <span>
                            <p class="font-bold text-base">Name*</p>
                            <input type="text" wire:model = 'name'
                                class=" w-full rounded-md border-0 bg-input-light  p-2">
                            @error('name')
                                <span class="error">{{ $message }}</span>
                            @enderror
                        </span>
                    </div>
                    <div class="col-span-2 lg:col-span-1">
                        <span>
                            <p class="font-bold text-base">Email*</p>
                            <input type="text" wire:model='email'
                                class=" w-full rounded-md border-0 bg-input-light p-2">
                            @error('email')
                                <span class="error">{{ $message }}</span>
                            @enderror
                        </span>
                    </div>
                    <div class="col-span-2 ">
                        <span>
                            <p class="font-bold text-base">Subject</p>
                            <input type="text" wire:model='subject'
                                class=" w-full rounded-md border-0 bg-input-light p-2">
                            @error('subject')
                                <span class="error">{{ $message }}</span>
                            @enderror
                        </span>
                    </div>
                    <div class="col-span-2 ">
                        <span>
                            <p class="font-bold text-base">Comment</p>
                            <textarea name="" wire:model='content' class="w-full rounded-md border-0 bg-input-light p-2" id=""
                                cols="30" rows="10"></textarea>
                            @error('content')
                                <span class="error">{{ $message }}</span>
                            @enderror
                        </span>
                    </div>

                </div>
                <div class="">
                    <button class="bg-orange w-full text-white py-2 rounded mt-8" wire:click='send'
                        wire:loading.attribute='disabled'><i class="fa fa-spinner hidden "
                            wire:loading.class.remove="hidden" wire:target="send"></i>
                        Send My Message
                    </button>
                </div>
            </div>
            <div class="col-span-1 lg:col-span-1"></div>
        </div>
    </div>
    <div class="w-full">
        <iframe class="w-full"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3979.6229865404234!2d9.738466875881617!3d4.096890146594219!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x10610f2503854381%3A0x8abdb3ff7a9c1a71!2sCarrefour%20Yoro%20Joss%2C%20Bonamoussadi!5e0!3m2!1sfr!2sde!4v1708426397132!5m2!1sfr!2sde"
            height="450" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>

</div>
