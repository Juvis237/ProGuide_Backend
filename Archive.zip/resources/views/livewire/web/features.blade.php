<section class="justify-center bg-slate-100">
    {{-- hero --}}
    <div class="bg-cover py-8 px-6 bg-no-repeat bg-bottom" style="background-image: url('/images/featured_bg.png');">
        <div
            class="container  max-w-screen-xl mx-auto   flex  flex-col-reverse md:flex-row items-center space-y-0 md:space-y-0">
            <div class="md:w-1/2">
                <img src="{{ asset('/images/featured hero image.png') }}" alt="Hero Image">
            </div>
            <div class="flex flex-col my-32 items-center md:pl-12 md:w-1/2 md:mt-8 md:items-start">
                <h1 class="text-4xl mb-5 font-bold text-white text-center md:text-left">
                    {!! \App\Models\Page::find(10)->title !!}
                </h1>
                <p class="text-white text-center leading-6 mt-4 md:text-left">
                    {!! \App\Models\Page::find(10)->content !!}
                </p>
            </div>
        </div>
    </div>
    {{-- clients find pro4home --}}
    <div class="container flex flex-col px-6 items-center mx-auto md:-mt-16 space-y-12 md:space-y-0 md:flex-row">
        <div class="flex flex-col space-y-8 md:w-1/2">
            <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                <div class="mx-auto md:mx-12">
                    <span class="my-4 px-4 py-2 text-sm bg-light-blue text-secondary rounded-full font-bold">
                        Workers
                    </span>
                    <h1 class=" my-4 text-4xl font-extrabold md:block">
                        {!! \App\Models\Page::find(11)->title !!}
                    </h1>
                    <p class="text-gray-600">
                        {!! \App\Models\Page::find(11)->content !!}
                    </p>

                </div>
            </div>
        </div>
        <div class="hidden lg:flex flex-col space-y-12 md:w-1/2">
            <img src="{{ asset('/images/pro4home-onboardingt-screen 2.png') }}" class="w-3/4 h-auto" alt="">
        </div>
    </div>
    {{-- create and customize your business profile --}}
    <div class=" bg-cover bg-no-repeat px-6 md:px-auto" style="background-image: url('/images/Rectangle 813.png');">
        <div
            class="container flex flex-col justify-between max-w-screen-xl items-center md:-mt-16 space-y-12 md:space-y-0 md:flex-row">
            <div class="flex flex-col space-y-12 md:w-1/2">
                <img src="{{ asset('/images/pro4home-workers-screen 1.png') }}" class="" alt="">
            </div>
            <div class="flex flex-col py-4 space-y-8 md:w-1/2">
                <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                    <div class="mx-auto md:mx-12 lg:mt-16">
                        <span class="my-4 px-4 py-2 text-sm bg-light-blue text-secondary rounded-full font-bold">
                            Workers
                        </span>
                        <h1 class=" my-4 text-4xl font-extrabold text-white md:block">
                            {!! \App\Models\Page::find(12)->title !!}

                        </h1>
                        <p class="text-white">
                            {!! \App\Models\Page::find(12)->content !!}

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- promote your business and services --}}
    <div class="container flex flex-col px-6 items-center mx-auto  space-y-12 md:space-y-0 md:flex-row">
        <div class="flex flex-col space-y-8 md:w-1/2">
            <div class="flex flex-col space-y-3 md:space-y-0 md:space-x-6 md:flex-row">
                <div class="mx-auto md:mx-12 mt-16 lg:mt-8">
                    <span class="my-4 px-4 py-2 text-sm bg-light-blue text-secondary rounded-full font-bold">
                        Workers
                    </span>
                    <h1 class=" my-4 text-4xl font-extrabold md:block">
                        {!! \App\Models\Page::find(13)->title !!}
                    </h1>
                    <p class="text-gray-600">
                        {!! \App\Models\Page::find(13)->content !!}
                    </p>
                </div>
            </div>
        </div>
        <div class="hidden md:flex flex-col space-y-12 md:w-1/2 ">
            <img src="{{ asset('/images/Group 1807.png') }}" class="w-3/4 h-auto" alt="">
        </div>
    </div>
    {{-- cards --}}
    <div class="flex flex-col md:flex-row bg-light justify-center gap-8 py-16 px-6 lg:px-24 items-center">
        <div class="w-full max-w-md px-8 py-16 mt-16 bg-white rounded-xl border-b-4 border-b-secondary-2 shadow-lg">
            <div class="flex justify-center -mt-32 ">
                <div
                    class="object-cover flex items-center justify-center p-8 border border-light bg-white rounded-full">
                    <img class=" " alt="Testimonial avatar" src="{{ asset('images/icon-portfolio.svg') }}">
                </div>

            </div>

            <h2 class="my-2 mx-auto text-2xl text-center font-bold md:mt-0">Display a portfolio of your past work and
                Win More Customers</h2>

            <p class="my-2 mx-auto text-sm text-center text-gray-600 ">Lorem ipsum dolor sit amet consectetur
                adipisicing elit. Quae dolores deserunt ea doloremque natus error, rerum quas odio quaerat nam ex
                commodi hic, suscipit in a veritatis pariatur minus consequuntur!</p>
        </div>
        <div class="w-full max-w-md px-8 py-16 mt-16 bg-white rounded-lg border-b-4 border-b-orange shadow-lg">
            <div class="flex justify-center -mt-32 ">
                <div
                    class="object-cover flex items-center justify-center p-8 border border-light bg-white rounded-full">
                    <img class=" " alt="Testimonial avatar" src="{{ asset('images/icon-users.svg') }}">
                </div>

            </div>

            <h2 class="my-2 mx-auto text-2xl text-center font-bold  md:mt-0">Outsource some of your tasks to other
                professionals</h2>

            <p class="my-2 mx-auto text-sm text-center text-gray-600 ">Lorem ipsum dolor sit amet consectetur
                adipisicing elit. Quae dolores deserunt ea doloremque natus error, rerum quas odio quaerat nam ex
                commodi hic, suscipit in a veritatis pariatur minus consequuntur!</p>
        </div>
    </div>
    <section class="my-24">


        <div class="container px-6  md:mx-auto">
            <div class="shadow-2xl bg-gray-50 rounded-2xl mt-10 p-4 py-16">
                <h1 class="text-4xl md:text-5xl mb-5 text-gray-600 font-bold text-center">
                    Get <span class="text-secondary">Pro</span><span class="text-orange">4</span><span
                        class="text-secondary">Home</span> App Now
                </h1>
                <p class="text-center leading-6 mt-4 md:px-32">
                    And start Finding the right professionals or advertise your services
                </p>
                <div class="flex flex-row justify-center mt-6 space-x-4">
                    <a href="{!! \App\Models\Page::find(17)->content !!}">
                        <img src="{{ asset('images/img_homepage/appstore12.png') }}" alt="">
                    </a>
                    <a href="{!! \App\Models\Page::find(18)->content !!}">
                        <img src="{{ asset('images/img_homepage/playstore.png') }}" alt="">
                    </a>
                </div>
            </div>
        </div>
    </section>
</section>
