<div>
    <p class="font-bold text-2xl">Comments({{$comments->count()}})</p>

    <div class="py-8">
        @foreach ($comments as $comment)

        @if (!isset($comment->parent_id))
                        <div class="mt-8 flex ">

                            <div class="mx-4 w-full">
                                <div class="mt-8">
                                    <div class="grid grid-cols-2">
                                        <div class="col-span-2 md:col-span-1">
                                            <div class="flex items-end">
                                                <div class="overflow-hidden w-12">
                                                    <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" class="mx-0" preserveAspectRatio="none">
                                                        <rect fill="#E4EDF2" x="0" y="0" height="40" width="40" x="50" rx="10"></rect>
                                                        <text fill="#B2C8D6" font-size="25" text-anchor="middle" x="20" y="30" font-weight="bold">
                                                            {{ $comment->initials}}
                                                        </text>
                                                    </svg>
                                                </div>
                                                <span class="mx-3">
                                                    <p class="font-bold text-base">{{$comment->name}}</p>
                                                    <p class="text-xs font-bold">{{$comment->created_at->diffForHumans()}}</p>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-span-2 md:col-span-1 flex justify-end">
                                            <div>
                                                <button class=" flex items-center rounded px-4 py-2 border border-secondary-2 text-secondary-2" wire:click="$emit('showReply',{{$comment->id}})">
                                                    <i class="me-2"><img src="{{asset('images/icon-reply.svg')}}" alt=""></i> Reply Comment
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="py-8 border-b">
                                        {{$comment->content}}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div class="rounded-xl p-4 bg-dark {{!($showReplyVar && $reply_comment == $comment->id)? 'hidden' : ''}} ">
                            <div class="my-16 p-8 md:p-16 rounded-lg border-t-2 border-b-2">
                                <p class="font-bold text-2xl">Leave a Comment</p>
                                <div class="grid grid-cols-2 gap-4 my-8">
                                    <div class="col-span-2 lg:col-span-1">
                                        <span>
                                            <p class="font-bold text-base">Name</p>
                                            <input type="text" wire:model='name' class=" w-full rounded-md border p-2">
                                        </span>
                                    </div>
                                    <div class="col-span-2 lg:col-span-1">
                                        <span>
                                            <p class="font-bold text-base">Email</p>
                                            <input type="text" wire:model='email' class=" w-full rounded-md border p-2">
                                        </span>
                                    </div>
                                    <div class="col-span-2 ">
                                        <span>
                                            <p class="font-bold text-base">Comment</p>
                                            <textarea name="" wire:model='content' class="w-full rounded-md border p-2" id="" cols="30" rows="10"></textarea>
                                        </span>
                                    </div>
                                </div>
                                <x-button class="mt-8 rounded-md bg-secondary-2 text-white p-2" wire:click="$emit('reply',{{$comment->id}})">Post Comment</x-button>
                            </div>

                        </div>
                        @foreach (\App\Models\Comment::where('parent_id', $comment->id)->get() as $reply)
                        <div class="mt-8 flex ms-16 ">
                            <div class="mx-4 w-full">
                                <div class="mt-8">
                                    <div class="grid grid-cols-2">
                                        <div class="col-span-2 md:col-span-1">
                                            <div class="flex items-end">
                                                <div class="overflow-hidden w-12">
                                                    <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg" class="mx-0" preserveAspectRatio="none">
                                                        <rect fill="#E4EDF2" x="0" y="0" height="40" width="40" x="50" rx="10"></rect>
                                                        <text fill="#B2C8D6" font-size="25" text-anchor="middle" x="20" y="30" font-weight="bold">
                                                            {{ $reply->initials}}
                                                        </text>
                                                    </svg>
                                                </div>
                                                <span class="mx-3">
                                                    <p class="font-bold text-base">{{$reply->name}}</p>
                                                    <p class="text-xs font-bold">{{$reply->created_at->diffForHumans()}}</p>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="py-8 border-b">
                                        {{$reply->content}}
                                    </p>
                                </div>
                            </div>
                        </div>
                        @endforeach


                    @endif

        @endforeach
        <div class="lg:col-span-2 {{$showReplyVar ? 'hidden' : ''}}">

            <div class="my-16 p-8 md:p-16 rounded-lg border-t-2 border-b-2">
                <p class="font-bold text-2xl">Leave a Comment</p>
                <div class="grid grid-cols-2 gap-4 my-8">
                    <div class="col-span-2 lg:col-span-1">
                        <span>
                            <p class="font-bold text-base">Name</p>
                            <input type="text" wire:model='name' class=" w-full rounded-md border p-2">
                        </span>
                    </div>
                    <div class="col-span-2 lg:col-span-1">
                        <span>
                            <p class="font-bold text-base">Email</p>
                            <input type="text" wire:model='email' class=" w-full rounded-md border p-2">
                        </span>
                    </div>
                    <div class="col-span-2 ">
                        <span>
                            <p class="font-bold text-base">Comment</p>
                            <textarea name="" wire:model='content' class="w-full rounded-md border p-2" id="" cols="30" rows="10"></textarea>
                        </span>
                    </div>
                </div>
                <x-button class="mt-8 rounded-md bg-secondary-2 text-white p-2" wire:click='sendComment'>Post Comment</x-button>
            </div>
        </div>

        <x-button class="mt-8 rounded-md bg-secondary-2 text-white p-2">Load 12 More Comments</x-button>

    </div>

</div>

