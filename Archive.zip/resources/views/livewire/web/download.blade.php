<div class="flex flex-col-reverse  md:flex-row ">
    <div class="flex  flex-col w-full lg:w-1/2">
        <div class="bg-light-blue px-4  md:px-auto py-14">
            <div class="container ">
                <h1 class="text-3xl mb-5 text-gray-600 font-bold text-center">
                    <span class="text-secondary">Pro</span><span class="text-orange">4</span><span
                        class="text-secondary">Home</span> for Android
                </h1>
                <div>
                    <p class="text-center mt-4 md:px-32">
                        By downloading Pro4Home, you accept our
                        <span class="text-secondary">terms of service</span> and <span class="text-secondary">privacy
                            policy</span>
                    </p>
                    <div class="flex justify-center mt-6 ">
                        <a href="{!! \App\Models\Page::find(18)->content !!}">
                            <img src="{{ asset('images/img_homepage/playstore.png') }}" alt="">
                        </a>
                    </div>
                </div>

            </div>
        </div>
        <div class="bg-pink px-4  md:px-auto bg-light-orange py-14">
            <div class="container ">
                <h1 class="text-3xl mb-5 text-gray-600 font-bold text-center">
                    <span class="text-secondary">Pro</span><span class="text-orange">4</span><span
                        class="text-secondary">Home</span> for iOS
                </h1>
                <p class="text-center  mt-4 md:px-32">
                    By downloading Pro4Home, you accept our
                    <span class="text-secondary">terms of service</span> and <span class="text-secondary">privacy
                        policy</span>
                </p>
                <div class="flex justify-center mt-6 ">
                    <a href="{!! \App\Models\Page::find(17)->content !!}">
                        <img src="{{ asset('images/img_homepage/appstore12.png') }}" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class=" mx-auto hidden lg:flex max-w-screen-xl pt-14 -ml-8 lg:w-1/2">
        <div class="z-40 w-full">
            <img src="{{ asset('images/download_img.png') }}" class="w-auto h-full" alt="">
        </div>
    </div>
</div>
