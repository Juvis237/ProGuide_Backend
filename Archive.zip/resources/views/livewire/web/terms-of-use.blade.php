<div class="bg-light-blue">
    <div class="container mx-auto items-center py-16">
        <h1 class="text-4xl mb-5 font-extrabold text-center">{!! \App\Models\Page::find(2)->title !!}</h1>
        <div class="flex justify-center">
            <hr class="border-2 border-orange w-20">
        </div>
    </div>
</div>

<section class="my-12">
    <div class="container mx-auto">
        <div class="flex flex-col md:flex-row">
            <div class="w-1/4">
                <div class="bg-white border rounded-2xl p-12 items-center hidden md:flex-wrap md:block ">
                    <ul class="list-none">
                        <li class="text-secondary py-4 border-b">
                            Your Agreement
                        </li>

                        <li class=" py-4 border-b">
                            Terms of Use
                        </li>

                        <li class=" py-4">
                            Access and Use of the Services
                        </li>
                    </ul>
                </div>
            </div>

            <div class="mx-10 md:w-3/4">
                {!! \App\Models\Page::find(2)->content !!}
            </div>
        </div>
    </div>
</section>
