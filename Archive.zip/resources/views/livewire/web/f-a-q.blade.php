<div>

    @include('components.header', with([
        "title" => "Frequently Asked Questions",

        ]))

    <section class="my-12">
        <div class="container mx-auto">
            <div class="flex flex-col md:flex-row md:space-y-4">
                <div class="items-center hidden md:flex-col md:block md:w-1/4">
                    <div class="bg-secondary rounded-2xl p-12">
                        <ul class="text-white list-none">
                            <li>
                                All Questions
                            </li>
                            <hr class="border-white my-4 w-full">
                            <li>
                                For Workers
                            </li>
                            <hr class="border-white my-4 w-full">
                            <li>
                                Managing your Account
                            </li>
                            <hr class="border border-white my-4 w-full">
                            <li>Payments</li>
                        </ul>
                    </div>
                    <div class="bg-cover rounded-lg p-8 mt-4" style="background-image: url('/images/Frame 1990.png');">
                        <div class="bg-white rounded-2xl p-8 bg-opacity-50">
                            <h2 class="font-bold text-2xl">Do you have More Questions?</h2>
                            <p class="">Lorem ipsum dolor sit amet
                                consectetur. Felis gravida id sodales
                                vitae volutpat non eu egestas. Ac
                                faucibus et adipiscing quis enim
                                tempor scelerisque.</p>
                            <button class="rounded-lg bg-orange w-full text-white items-center py-4 px-8 my-8">
                                Button
                            </button>
                        </div>
                    </div>
                </div>
                <div class="mx-10 md:w-3/4">

                    <div id="accordion-collapse" data-accordion="collapse">
                        @foreach ($faqs as $faq)
                            <h2 id="accordion-collapse-heading-{{$faq->id}}">
                                <button type="button"
                                        class="flex items-center justify-between w-full p-5 font-medium text-black rounded-lg my-4 shadow-xl border border-light shadow-light  hover:text-white   hover:bg-secondary-2 rounded-t-xl "
                                        data-accordion-target="#accordion-collapse-body-{{$faq->id}}" aria-expanded="true"
                                        aria-controls="accordion-collapse-body-{{$faq->id}}">
                                    <span>{{$faq->question}}</span>
                                    <svg data-accordion-icon class="w-3 h-3 rotate-180 shrink-0" aria-hidden="true"
                                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
                                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                            stroke-width="2" d="M9 5 5 1 1 5" />
                                    </svg>
                                </button>
                            </h2>
                            <div id="accordion-collapse-body-{{$faq->id}}" class="hidden" aria-labelledby="accordion-collapse-heading-{{$faq->id}}">
                                <div class="p-5 border border-b-0 border-gray-200  ">
                                    <p class="mb-2 text-gray-500 ">{{$faq->answer}}</p>
                                </div>
                            </div>
                        @endforeach
                    </div>

                </div>
            </div>
        </div>
    </section>  
</div>