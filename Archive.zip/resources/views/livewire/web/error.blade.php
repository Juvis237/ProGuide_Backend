<section class="bg-cover bg-no-repeat bg-bottom" style="background-image: url('/images/404 PAGE.png');">
    <div class="flex flex-col py-16 items-center">
        <div class="">
            <img src="{{ asset('/images/404.png') }}" alt="">
            <h1 class="text-white font-extrabold text-4xl text-center">PAGE NOT FOUND</h1>
            <p class="text-center text-white mt-4">We can’t seem to find the page you’re looking for
            </p>
        </div>
        <button class="rounded-lg bg-orange text-white items-center py-4 px-8 my-8">
            Back to Homepage
        </button>
    </div>
</section>
