<div class="bg-light-blue">
    <div class="container mx-auto items-center py-16">
        <h1 class="text-4xl mb-5 font-extrabold text-center">{!! \App\Models\Page::find(1)->title !!}</h1>
        <div class="flex justify-center">
            <hr class="border-2 border-orange w-20">
        </div>
    </div>
</div>

<section class="my-12">
    <div class="container mx-auto">
        {!! \App\Models\Page::find(1)->content !!}
    </div>
</section>
