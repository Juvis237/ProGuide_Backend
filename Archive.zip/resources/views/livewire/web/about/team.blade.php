<div>
    @include('components.header', with([
        "title" => "Meet out Team",

        ]))
    
    <x-container class="my-8">
        <div class="grid gap-4 grid-cols-4">
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-1.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Chelsea Larson-Howe</p>
                    <p class="text-secondary-2">Direct Web Coordinator</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-2.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Cora Blick</p>
                    <p class="text-secondary-2">Senior Division Liaison</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-3.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Jay Schumm</p>
                    <p class="text-secondary-2">Internal Brand Planner</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-4.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Ernestine Klocko</p>
                    <p class="text-secondary-2">Direct Assurance Architect</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-5.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">David Franey</p>
                    <p class="text-secondary-2">Principal Response Technician</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-6.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Jean Baumbach</p>
                    <p class="text-secondary-2">Lead Data Supervisor</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-7.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Al Pfannerstill</p>
                    <p class="text-secondary-2">Dynamic Identity Technician</p>
                </div>
            </div>
            <div class="col-span-4 lg:col-span-1 ">
                <div class=" rounded shadow-sm shadow-secondary-2 p-4">
                    <img src="{{ asset('images/img-about-team-8.png') }}" alt="">
                    <p class="text-xl font-bold mt-8">Alison Johnson</p>
                    <p class="text-secondary-2">Human Solutions Specialist</p>
                </div>
            </div>
        </div>
    </x-container>
</div>
