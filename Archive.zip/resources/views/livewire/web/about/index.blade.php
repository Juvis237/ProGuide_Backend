<div>
    @include('components.header', with([
        "title" => "About Us",

        ]))
        <x-container class="my-10">
            <div class="grid grid-cols-3">
                <div class="col-span-3 lg:col-span-1 ">
                    <div class="flex items-center h-full">
                        <div class=" w-full border-b py-2">
                            <p class="font-bold text-4xl"> Our Story</p>
                        </div>
                    </div>

                </div>
    
                <div class=" col-span-3 lg:col-span-2">
                    <div class="border-l p-10">
                        <p class="font-bold text-4xl text-secondary-2 mb-4 "> We connect businesses and customers</p>
                        <p>Lorem ipsum dolor sit amet consectetur. Venenatis eget fames eros facilisis nisl platea. Vel sed morbi dignissim enim pulvinar adipiscing tellus. Laoreet elit ultrices quis sed adipiscing aliquet enim cursus feugiat. Suscipit nulla aenean dui risus.
                            Nulla massa sed cursus ipsum lorem cum mauris sagittis convallis. Sagittis id eget morbi enim suspendisse id amet. Pretium dolor adipiscing duis suspendisse quam lorem lectus rhoncus ut. In malesuada enim venenatis eu. Vulputate leo ut eget facilisis ultrices ac nibh iaculis cras. Amet pellentesque tincidunt enim dolor congue nibh at porttitor. Risus etiam aliquet lectus id aliquet. Vel iaculis ac amet rhoncus id. Eleifend viverra turpis libero integer. Interdum commodo vestibulum aenean consectetur at lorem egestas cursus. Pretium purus orci id justo nunc lacus. Nam lacus tincidunt tellus nec. Euismod senectus sit adipiscing enim nunc. Luctus adipiscing pretium rhoncus tellus ipsum varius bibendum sed</p>
                    </div>
                </div>
            </div>
        </x-container>

        <x-container>
            <div class="grid grid-cols-3">
                <div class="col-span-3 lg:col-span-1">
                    <span>
                        <div class=" rounded-md px-4 py-8 border-b-4 mb-10 border border-light border-b-secondary shadow-2xl shadow-light hover:border-b-orange ">
                            <p class="text-3xl font-bold mb-3 text-center"> Our Mission</p>
                            <p class="text-center">Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam. Arcu dignissim nisl turpis laoreet neque quis</p>
                        </div>
                        <div class=" rounded-md px-4 py-8 border-b-4 mb-10 border border-light text-center border-b-orange shadow-2xl shadow-light ">
                            <p class="text-3xl font-bold mb-3 "> Our Vision</p>
                            <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam. Arcu dignissim nisl turpis laoreet neque quis</p>
                        </div>
                        <div class=" rounded-md px-4 py-8 border-b-4 border border-light mb-10 text-center border-b-black shadow-2xl shadow-light hover:border-b-secondary ">
                            <p class="text-3xl font-bold mb-3 "> Our Values</p>
                            <p>Lorem ipsum dolor sit amet consectetur. A et ut viverra eget erat arcu nullam. Arcu dignissim nisl turpis laoreet neque quis</p>
                        </div>
                    </span>
                </div>
                <div class="col-span-2">
                    <div class="p-10 hidden lg:flex ">
                        <img src="{{ asset('images/img-about-about Pro4home.png') }}" alt="">
                    </div>
                </div>
            </div>
        </x-container>
        <x-container>
            <div class="grid gap-4 grid-cols-3">
                <div class="col-span-3 lg:col-span-1  transition delay-150 duration-300 ease-in-out hover:scale-105">
                    <a href="{{route('about.blog')}}" class=""><img src="{{ asset('images/img-about-us-blog.png') }}" alt=""></a>
                    
                </div>
                <div class="col-span-3 lg:col-span-1 transition delay-150 duration-300 ease-in-out hover:scale-105">
                    <a href="{{route('contact')}}">
                        <img src="{{ asset('images/img-about-us-contact.png') }}" alt="">
                    </a>
                    
                </div>
                <div class="col-span-3 lg:col-span-1 transition delay-150 duration-300 ease-in-out hover:scale-105">
                    <a href="{{route('about.team')}}">
                        <img src="{{ asset('images/img-about-us-team.png') }}" alt="">
                    </a> 
                </div>
            </div>
        </x-container>

</div>
