<div>
    <x-container class="mt-16">
        <div class="grid gap-4 grid-cols-3">
            <div class="col-span-3 lg:col-span-1 flex items-center text-center">
                <span>
                    <p class="text-3xl font-bold my-4">{{$blog->title}}</p>
                    <div class="flex mt-4 justify-center">
                        <p>{{date_format($blog->created_at,"M j, Y")}} |  By : </p>
                        <p class="text-secondary-2">{{$blog->publisher()}}</p>
                    </div>
                </span>
            </div>
            <div class="col-span-3 lg:col-span-2">
                <img src="{{ $blog->coverImage() }}" class="rounded-lg w-full h-full" alt="">
            </div>
        </div>
        <div class="mt-8 md:px-16 pt-8">
            <p>
                {!!$blog->description!!}
            </p>

            <div class="bg-light my-16 rounded py-8 px-16">
                <p class="italic font-semibold text-2xl">Lorem ipsum dolor sit amet consectetur. Porttitor aliquam tempor tellus sit volutpat.</p>
                <p class="font-bold text-secondary-900">by Asha Gray</p>
                
            </div>

            <livewire:web.comments :post="$blog" />

            <div class="my-16">
                <div class="grid grid-cols-2">
                    <div class="col-span-2 md:col-span-1">
                        <p class="text-xl font-bold">Related Articles</p>
                    </div>
                    <div class="col-span-2 md:col-span-1 flex justify-end">
                        <div>
                            <a href="{{route('about.blog')}}" class="text-secondary"> See more articles</a>
                        </div>
                    </div>
                </div>
            </div>
    
            <div class="grid grid-cols-3 gap-4 ">
                @foreach($blog->related()->take(3) as $related)
                    <div class="col-span-3 lg:col-span-1">
                        <a href="{{route('blog.detail', $related)}}">
                            <div>
                                <img src="{{ $related->coverImage() }}" alt="" class="rounded w-full h-full">
                                <div class="py-4 px-4 text-wrap">
                                    <span>
                                        <p class="text-2xl font-bold">
                                            {{$related->title}}
                                        </p>
                                        <div class="flex mt-4 ">
                                            <p>{{date_format($blog->created_at,"M j, Y")}} |  By : </p>
                                            <p class="text-secondary-2">{{$blog->publisher()}}</p>
                                        </div>
                                    </span>
                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
            </div>
        </div>
    </x-container>
</div>
