<div>
    @include('components.header', with([
        "title" => "Our Blog",

        ]))

    <x-container class="my-16">
        <div class="grid gap-4 grid-cols-3">
            <div class="col-span-3 lg:col-span-2">
                <img src="{{ asset('images/img-about-blog-hero.png') }}" alt="">
            </div>
            <div class="col-span-3 lg:col-span-1 flex items-center">
                <span>
                    <div class="px-4 py-2 bg-light text-secondary-900 w-24 text-center  text-bold rounded-full">
                        category
                    </div>
                    <p class="text-3xl font-bold my-4 text-dark-400">Lorem ipsum dolor sit amet consectetur. A sem blandit mi pellentesque neque</p>
                    <p class=" my-4">auris pharetra eget viverra feugiat eu quisque vestibulum. Vehicula euismod at amet varius euismod quis dignissim. Tortor eget aliquet massa mi nulla ut. Sodales morbi platea dignissim tellus molestie</p>
                </span>
            </div>
        </div>
        <div class="my-16">
            <div class="grid grid-cols-2">
                <div class="col-span-2 md:col-span-1">
                    <p class="text-4xl font-bold">All Articles</p>
                </div>
                <div class="col-span-2 md:col-span-1 flex justify-end">
                    <div class=" ">
                        <input type="text" class="p-2 rounded border" wire:model="filters.name" placeholder="Search article here...">
                        <i class="fa fa-search -mx-6"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-3 gap-4">
            @foreach ($blogs as $blog)
                <div class="col-span-3 lg:col-span-1">
                    <a href="{{route('blog.detail', $blog)}}">
                        <div>
                            <img src="{{ $blog->coverImage() }}" alt="" class="rounded w-full h-full">
                            <div class="py-4 px-4 text-wrap">
                                <span>
                                    <p class="text-2xl text-dark-400 font-bold">
                                        {{$blog->title}}
                                    </p>
                                    <div class="flex mt-4">
                                        <p>{{date_format($blog->created_at,"M j, Y")}} |  By : </p>
                                        <p class="text-secondary-2">{{$blog->publisher()}}</p>
                                    </div>
                                </span>
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>

    </x-container>
</div>
