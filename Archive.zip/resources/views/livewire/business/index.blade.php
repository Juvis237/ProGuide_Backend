<div>
    <div class="d-flex mb-5 justify-content-between align-items-center">
        <h4 class="text-capitalize">Manage Business</h4>

        <a href="{{route('business.create')}}" class="btn btn-primary text-white" >
            <i class="fa fa-spinner d-none" ></i>
            Add Business
        </a>
    </div>


    <div class="d-flex justify-content-end flex-column flex-lg-row">
        <div class=" mb-3 mr-2">
            <select  wire:model.debounce.500ms="filters.category" wire:change='set_sub'  class="form-control">
                <option disabled value="">Select Category</option>
                <option  value="">All Categories</option>
                @foreach ($categories as $cat)
                    <option {{$cat->id == $filters['category']?"selected":""}}  value="{{$cat->id}}">{{$cat->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select  wire:model="filters.sub_category" class="form-control">
                <option disabled value="">Select Sub Category</option>
                <option  value="">All Sub Categories</option>
                @foreach ($sub_categories as $sub)
                    <option {{$sub->id == $filters['sub_category']?"selected":""}}  value="{{$sub->id}}">{{$sub->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select  wire:model="filters.region" wire:change='set_cities'  class="form-control">
                <option disabled value="">Select Region</option>
                <option  value="">All Regions</option>
                @foreach ($regions as $reg)
                    <option  {{$reg->id == $filters['region']?"selected":""}} value="{{$reg->id}}">{{$reg->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select  wire:model="filters.city" class="form-control">
                <option disabled value="">Select City</option>
                <option  value="">All Cities</option>
                @foreach ($cities as $cit)
                    <option {{$cit->id == $filters['city']?"selected":""}} value="{{$cit->id}}">{{$cit->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select name="" class="form-control rounded-md " id="">
                <option value="">Status</option>
            </select>
        </div>

        <div class=" mb-3 mr-2">
            <div class="">
                <input type="text" wire:model.debounce.500ms="filters.name" class="form-control  w-100  input-sm"
                       placeholder="Type to Search">
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered m-0">

            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Category</th>
                <th>Sub Category</th>
                <th>Location</th>
                <th>Joined On</th>
                <th>Status</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($users as $k=>$user)
                <tr wire:key="{{$k}}">
                    <td>{{$loop->index + 1}}</td>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="{{ !isset($user->profile)?  asset('be_assets/images/Frame 75.png') : asset('storage/'.$user->profile) }}" alt="user-image" width="60px" height="60px" class="rounded-circle mx-2">
                            {{$user->company}}
                        </div>
                    </td>
                    <td>
                        {{$user->services()==null? $user->services()->first()->title : ''}}
                    </td>
                    <td>
                        {{$user->services()==null? $user->services()->first()->title : ''}}
                    </td>
                    <td>{{$user->city_id.' '.$user->region_id}} </td>
                    <td>{{$user->created_at  }} </td>
                    <td class="p-2">
                        <div class=" p-2 rounded-lg badge badge-{{$user->status == '1' ? 'success' : 'processing'}}">
                            {{$user->status == '1' ? 'Active' : 'Inactive'}}
                        </div>
                         </td>
                    <td>
                        <div class="button-list">
                            <a href="{{route('user.detail', $user)}}" class="btn btn-primary"><i
                                class="fa fa-eye"></i> </a>
                            <a href="{{route('edit.user', ['user' => $user->id])}}"
                                class="btn btn-dark"><i class="fa fa-pen"></i></a>
                            <a href="#" wire:click.prevent="$emitTo('users.delete','load',{{$user}})"
                                class="btn btn-danger"><i class="fa fa-trash-alt"></i></a>
                        </div>
                    </td>

                </tr>
            @empty
                <tr>
                    <td colspan="8" class=" text-center">No Businesses Found</td>
                </tr>
            @endforelse

            </tbody>
        </table>
    </div>

        {{-- Pagination --}}
        @if($this->rows->count())
            <div class="mt-5">
                {{ $this->rows->links() }}
            </div>
        @endif
        {{-- / Pagination --}}
    <livewire:users.delete />
</div>
