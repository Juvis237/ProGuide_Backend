<div>
    <div class="d-flex mb-5 justify-content-between align-items-center">
        <h4 class="text-capitalize">Manage Users</h4>
    </div>


    <div class="d-flex justify-content-end flex-column flex-lg-row">
        <div class=" mb-3 mr-2">
            <select  wire:model="filters.region" wire:change='set_cities'  class="form-control">
                <option disabled value="">Select Region</option>
                <option  value="">All Regions</option>
                @foreach ($regions as $reg)
                    <option  {{$reg->id == $filters['region']?"selected":""}} value="{{$reg->id}}">{{$reg->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select  wire:model="filters.city" class="form-control">
                <option disabled value="">Select City</option>
                <option  value="">All Cities</option>
                @foreach ($cities as $cit)
                    <option {{$cit->id == $filters['city']?"selected":""}} value="{{$cit->id}}">{{$cit->name}}</option>
                @endforeach
            </select>
        </div>
        <div class=" mb-3 mr-2">
            <select name="" class="form-control rounded-md " id="">
                <option value="">Status</option>
            </select>
        </div>

        <div class=" mb-3 mr-2">
            <div class="">
                <input type="text" wire:model.debounce.500ms="filters.name" class="form-control  w-100  input-sm"
                       placeholder="Type to Search">
            </div>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered m-0">

            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Role</th>
                <th>Region</th>
                <th>City</th>
                <th>Joined On</th>
                <th>Status</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            @forelse($users as $k=>$user)
                <tr wire:key="{{$k}}">
                    <td>{{$loop->index + 1}}</td>
                    <td>
                        {{$user->first_name}}
                    </td>
                    <td>
                        {{$user->phone}}
                    </td>
                    <td>{{$user->email}} </td>
                    <td>{{$user->role  }} </td>
                    <td>
                        {{isset($user->region)?$user->region->name:""}}
                    </td>
                    <td>
                        {{isset($user->city)?$user->city->city:""}}
                    </td>
                    <td>{{$user->created_at}} </td>
                    <td class="p-2">
                        <div class=" p-2 rounded-lg badge badge-{{$user->status == '1' ? 'success' : 'processing'}}">
                            {{$user->status == '1' ? 'Active' : 'Inactive'}}
                        </div>
                         </td>
                    <td>
                        <div class="button-list">
                            <a href="{{route('user.detail', $user)}}" class="btn btn-primary"><i
                                class="fa fa-eye"></i> </a>
                        </div>
                    </td>

                </tr>
            @empty
                <tr>
                    <td colspan="8" class=" text-center">No users found</td>
                </tr>
            @endforelse

            </tbody>
        </table>
    </div>

        {{-- Pagination --}}
        @if($this->rows->count())
            <div class="mt-5">
                {{ $this->rows->links() }}
            </div>
        @endif
        {{-- / Pagination --}}
</div>
