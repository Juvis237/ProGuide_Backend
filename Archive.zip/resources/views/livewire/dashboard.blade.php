<div>
    <div class="row justify-content-between align-items-center">
        <div class="col-md-6 col-lg-8 d-flex justify-content-between align-items-center">
            <h5 class="text-capitalize breadcrumb-heading">Dashboard</h5>
        </div>
        <nav class="breadcrumb-nav" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item" aria-current="page" style="color: #026BCF;">Dashboard</li>
            </ol>
        </nav>
    </div>
    <div class="justify-content-between">
        <div class="row">
            @include(
                'components.card',
                with([
                    'link' => route('business.index'),
                    'icon' => asset('images/organisation.svg'),
                    'title' => 'Businesses',
                    'figure' => $businessCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('skills'),
                    'icon' => asset('images/apartment.svg'),
                    'title' => 'Business Category',
                    'figure' => $businessCategoryCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('requests'),
                    'icon' => asset('images/icon_request_received.svg'),
                    'title' => 'Total Requests',
                    'figure' => $requestCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('admin.dashboard'),
                    'icon' => asset('images/business_service.svg'),
                    'title' => 'Business Services',
                    'figure' => $businesServiceCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('index.user', ['type' => 'client']),
                    'icon' => asset('images/user.svg'),
                    'title' => 'Total Users',
                    'figure' => $UserCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('index.user', ['type' => 'worker']),
                    'icon' => asset('images/user.svg'),
                    'title' => 'Total Admins',
                    'figure' => $adminUserCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('pages.index'),
                    'icon' => asset('images/pages.svg'),
                    'title' => 'Pages',
                    'figure' => $pageCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('blogs'),
                    'icon' => asset('images/blog.svg'),
                    'title' => 'Blog',
                    'figure' => $blogCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('testimonial'),
                    'icon' => asset('images/testimonails.svg'),
                    'title' => 'Testimonials',
                    'figure' => $testimonialCount,
                ]))
            @include(
                'components.card',
                with([
                    'link' => route('faqs.admin'),
                    'icon' => asset('images/faqs.svg'),
                    'title' => 'FAQS',
                    'figure' => $faqCount,
                ]))
        </div>
    </div>
</div>
