<x-mail::message>


# Hello

Your verification code is: {{ $otp }}

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
