<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>@yield('pageTitle', config('app.name'))</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="{{ asset('be_assets') }}/images/log.jpeg
">

    <link href="{{ asset('be_assets') }}/css/bootstrap.min.css" rel="stylesheet" type="text/css"
        id="bootstrap-stylesheet" />
    <link href="{{ asset('be_assets') }}/libs/select2/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="{{ asset('be_assets') }}/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="{{ asset('be_assets') }}/css/app.min.css" rel="stylesheet" type="text/css" id="app-stylesheet" />
    <link href="{{ asset('be_assets/css/toastr.css') }}" rel="stylesheet" type="text/css" id="app-stylesheet" />
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/custo.css') }}" rel="stylesheet">
    <link href="{{ asset('be_assets') }}/css/style.css" rel="stylesheet" type="text/css" />
    <link href="{{ asset('assets') }}/css/dashboard.css" rel="stylesheet">
    <link href="{{ asset('be_assets/css/toastr.css') }}" rel="stylesheet" type="text/css" id="app-stylesheet" />

    @livewireStyles
    <style>
        .error {
            color: #ff0000;
            font-size: 12px;
        }

        .btn {
            padding: 0.25rem 0.5rem;
            font-size: .875rem;
            line-height: 1.5;
            border-radius: 0.2rem;
        }

        [x-cloak] {
            display: none !important;
        }

        .overlay,
        .cover {
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            background: black;
            opacity: 0.75;
        }

        .user-box .user-info {
            z-index: 10;
        }

        .modal {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            overflow-y: scroll;
            z-index: 1000;
            width: 100%;
            height: 100%;
        }

        .modal-header {
            border-bottom: none;
        }

        .modal-footer {
            border-top: none;
        }

        .modal-inner {
            background-color: white;
            border-top: 20px #026BCF solid;
            border-radius: 0.5em;
            max-width: 1000px;
            width: 1000px;
            padding: 2em;
            margin: auto;
        }

        .modal-inner.short {
            max-width: 500px;
            width: 500px;
        }

        .btn.focus,
        .btn:focus {
            box-shadow: none;
        }

        .bg-orange-l {
            background-color: #FF9719;
        }

        .breadcrumb-heading {
            color: #000000;
            font-size: 24px;
            margin: 0;
            padding: 0;
        }

        .breadcrumb {
            background-color: transparent;
        }

        .breadcrumb-item+.breadcrumb-item::before {
            content: ">";
            color: #9dacbe;
        }

        ion-icon {
            font-size: 24px;
            color: #000000;
        }
        .dropdown-menu a :hover{
            text-decoration-color: #9dacbe !important;
            background-color: red !important;
        }
    </style>

</head>

<body>

    <div style="">
        <div id="" class="">

            <?php
            if (!auth()->user()->isAdmin() && \Auth::user()->clients()->count() > 0 && current_client() === null) {
                Session::put('current_client', \Auth::user()->clients()->first()->id);
            } elseif (!auth()->user()->isAdmin() && \Auth::user()->institutions()->count() > 0 && current_institution() === null) {
                Session::put('current_institution', \Auth::user()->institutions()->first()->id);
            }
            ?>


            <!-- Topbar Start -->
            <div class="navbar-custom bg-primary">

                <ul class="list-unstyled topnav-menu text-white float-right mb-0">

                    <livewire:notifications />

                    <li class="dropdown notification-list">
                        <a class="nav-link dropdown-toggle nav-user mr-0" data-toggle="dropdown" href="#"
                            role="button" aria-haspopup="false" aria-expanded="false">
                            <img src="{{ isset(auth()->user()->profile) ? auth()->user()->profile_picture : asset('be_assets/images/users/avatar-1.jpg') }}"
                                alt="user-image" class="rounded-circle">
                            <span class="pro-user-name ml-1 text-white">
                                {{ auth()->user()->name }}
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right profile-dropdown ">

                            <a href="{{ route('logout') }}" class="dropdown-item notify-item ">
                                Logout
                            </a>

                        </div>
                    </li>
                    <li class=" d-none d-md-flex align-items-center p-2">
                        <a href="">
                            <button class="btn border mx-2 p-2 mt-2">
                                <i class="fa fa-globe mx-2"></i> ENG <i class="fa fa-chevron-down mx-2  py-1  "></i>
                            </button>
                        </a>
                    </li>

                </ul>

                <!-- LOGO -->
                <div class="logo-box">
                    <a href="{{ route('admin.dashboard') }}" class="logo text-center logo-dark">
                        <span class="logo-lg">

                            <img src="{{ asset('be_assets') }}/images/Layer 2.png" alt="" height="40">
                            <!-- <span class="logo-lg-text-dark">Simple</span> -->
                        </span>
                        <span class="logo-sm">
                            <!-- <span class="logo-lg-text-dark">S</span> -->
                            <img src="{{ asset('be_assets') }}/images/log.jpeg" alt="" height="22">

                        </span>
                    </a>

                    <a href="{{ route('admin.dashboard') }}" class="logo text-center logo-light">
                        <span class="logo-lg">

                            <img src="{{ asset('be_assets') }}/images/Layer 2.png" alt="" height="60">

                            <!-- <span class="logo-lg-text-light">Simple</span> -->
                        </span>
                        <span class="logo-sm">
                            <!-- <span class="logo-lg-text-light">S</span> -->
                            <img src="{{ asset('be_assets') }}/images/log.jpeg" alt="" height="22">

                        </span>
                    </a>
                </div>

                <ul class="list-unstyled topnav-menu  topnav-menu-left m-0">
                    <li>
                        <button class="button-menu-mobile text-white">
                            <i class="mdi mdi-menu"></i>
                        </button>
                    </li>
                    <li class=" d-none d-md-flex align-items-center p-2 ">
                            <div class="dropdown ">
                                <button class="btn border mx-2 p-2 mt-2 dropdown-toggle  submenu-indicator " type="button"  id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                                    <i class="fa fa-plus mx-2"></i> Add <i
                                        class="fa fa-chevron-down mx-2 px-2 py-1  border-left"></i>
                                </button>
                                <div class="w-100">
                                    <div class="dropdown-menu position-relative bg-primary border-none " aria-labelledby="dropdownMenuButton">
                                      <a class="dropdown-item text-white " href="{{ route('business.create') }}">Business</a>
                                      <a class="dropdown-item text-white" href="{{ route('blogs', ['type' => 'text']) }}">Blog</a>
                                      <a class="dropdown-item text-white" href="{{ route('faqs.admin') }}">FAQ</a>
                                      <a class="dropdown-item text-white" href="{{ route('skills') }}">Skill</a>
                                    </div>
                                  </div>
                            </div>   
                    </li>
                    
                    <li class="d-none d-md-flex align-items-center p-2">
                        <a href="{{ route('findpro') }}">
                            <button class="btn bg-orange-l mx-2 p-2 mt-2">
                                <i class="fa fa-search"></i> Search for Workers
                            </button>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- end Topbar --> <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu bg-primary ">

                <div id="sidebar-menu">

                    <ul class="metismenu" id="side-menu">
                        <li>
                            <a href="{{ route('admin.dashboard') }}">
                                <i class="fa fa-home"></i>
                                <span> Dashboard</span>
                            </a>
                        </li>

                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-industry"></i>
                                <span>Manage Business</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level " style="">
                                <li><a href="{{ route('business.create') }}"><i class=""></i>Add Businesses</a>
                                <li><a href="{{ route('business.index') }}"><i class=""></i>All Businesses</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="{{ route('index.user') }}">
                                <i class="fa fa-users"></i>
                                <span>Manage Users</span>
                            </a>
                        </li>

                        <li><a href="{{ route('skills') }}"><i class="fa fa-tools"></i>Skills</a></li>
                        <li><a href="{{ route('requests') }}">
                                <i class="fa fa-question"></i>Requests</a></li>


                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-list"></i>
                                <span>Categories</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level " style="">

                                <li><a href="{{ route('categories', ['type' => 'blog']) }}"><i
                                            class=""></i>Blogs
                                        Categories</a></li>
                                <li><a href="{{ route('categories', ['type' => 'faq']) }}"><i class=""></i>FAQ
                                        Categories</a></li>

                            </ul>
                        </li>

                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-registered"></i>
                                <span>Blogs</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level " style="">
                                <li><a href="{{ route('blogs', ['type' => 'text']) }}"><i class=""></i>Blog</a>
                                </li>
                                <li><a href="{{ route('blogs', ['type' => 'video']) }}"><i class=" "></i>Video
                                        Blog</a>
                                </li>
                            </ul>
                        </li>
                        <li><a href="{{ route('faqs.admin') }}"><i
                                    class="fa fa-question-circle"></i><span>FAQs</span> </a></li>
                        <li><a href="{{ route('testimonial') }}"><i
                                    class="fa fa-comments"></i><span>Testimonials</span> </a></li>
                        <li><a href="{{ route('pages.index') }}"><i class="fa fa-book"></i><span>Pages</span>
                            </a></li>

                        <li>
                            <a href="javascript: void(0);">
                                <i class="fa fa-user"></i>
                                <span>Profile</span>
                                <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level " style="">
                                <li><a href="{{ route('change.password') }}"><i class=""></i>Change
                                        Password</a></li>
                                <li><a href="{{ route('update.profile') }}"><i class=""></i>My Profile</a></li>
                            </ul>
                        </li>

                    </ul>


                </div>
                <!-- End Sidebar -->

                <div class="clearfix"></div>


            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">

                    <!-- Start container-fluid -->
                    <div class="container-fluid">
                        @yield('content')
                        {{ $slot ?? '' }}
                    </div>
                    <!-- end container-fluid -->


                    <!-- Footer Start -->
                    <footer class="footer">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                    2023 &copy; @yield('pageTitle', config('app.name'))
                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- end Footer -->

                </div>
                <!-- end content -->

            </div>
            <!-- END content-page -->

        </div>
    </div>

    <!-- Begin page -->



    <!-- END wrapper -->

<!-- Vendor js -->
<script src="{{asset('be_assets')}}/js/vendor.min.js"></script>
<script src="{{asset('be_assets')}}/js/app.min.js"></script>
<script src="{{asset('be_assets/js/toastr.min.js') }}"></script>
<script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
<script src="https://cdn.tiny.cloud/1/s8i05r191jbb0uet8083xhpvoabmrj813lvht3pb2uwajslv/tinymce/6/tinymce.min.js"
        referrerpolicy="origin"></script>

    @livewireScripts

    <script>
        $(function() { //ready

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": false,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "hideDuration": "1000",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    };

                    Livewire.on('success', message => {
                        toastr.success(message);
                    })

                    @if (session()->has('success'))
                        toastr.success('{{ session()->get('success') }}');
                    @endif

                    @if (session()->has('error'))
                        toastr.error('{{ session()->get('error') }}');
                    @endif

                    Livewire.on('error', message => {
                        toastr.error(message);
                    });

                    Livewire.on('refreshParent', event => {
                        alert('the refreshParent event was fired');
                    });
    </script>

    });
    </script>
    @yield('script')

</body>

</html>
